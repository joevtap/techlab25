"use client"
import { AuthContainer } from "@/components/containers/AuthContainer"

export default function SignInPage() {
  return <AuthContainer mode="signin" />
}
