"use client"
import { AuthContainer } from "@/components/containers/AuthContainer"

export default function SignUpPage() {
  return <AuthContainer mode="signup" />
}
