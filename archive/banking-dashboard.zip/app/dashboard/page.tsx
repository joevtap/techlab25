"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { AccountsOverview } from "@/components/accounts-overview"
import { TransactionsPanel } from "@/components/transactions-panel"
import { DashboardHeader } from "@/components/dashboard-header"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import { CreateAccountModal } from "@/components/create-account-modal"
import { DashboardContainer } from "@/components/containers/DashboardContainer"

export default function DashboardPage() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [hasAccounts, setHasAccounts] = useState(true)
  const [isCreateAccountModalOpen, setIsCreateAccountModalOpen] = useState(false)

  useEffect(() => {
    // Check if user is authenticated
    const authStatus = localStorage.getItem("isAuthenticated") === "true"
    setIsAuthenticated(authStatus)

    if (!authStatus) {
      router.push("/sign-in")
      return
    }

    // Check if user has accounts
    const accountStatus = localStorage.getItem("hasAccounts") === "true"
    setHasAccounts(accountStatus)
  }, [router])

  if (!isAuthenticated) {
    return null // Will redirect in useEffect
  }

  return (
    <DashboardContainer>
      <main className="min-h-screen bg-gray-50">
        <DashboardHeader />
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold">Minhas Contas</h1>
            <Button onClick={() => setIsCreateAccountModalOpen(true)} className="flex items-center gap-2">
              <PlusCircle className="h-4 w-4" />
              Nova Conta
            </Button>
          </div>

          {hasAccounts ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1">
                <AccountsOverview />
              </div>
              <div className="lg:col-span-2">
                <TransactionsPanel />
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <h2 className="text-xl font-semibold mb-4">Você ainda não possui contas</h2>
              <p className="text-muted-foreground mb-6">Crie sua primeira conta para começar</p>
              <Button onClick={() => setIsCreateAccountModalOpen(true)} className="flex items-center gap-2">
                <PlusCircle className="h-4 w-4" />
                Criar Conta
              </Button>
            </div>
          )}
        </div>

        <CreateAccountModal isOpen={isCreateAccountModalOpen} onClose={() => setIsCreateAccountModalOpen(false)} />
      </main>
    </DashboardContainer>
  )
}
