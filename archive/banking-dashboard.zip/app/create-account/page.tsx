"use client"
import { CreateAccountContainer } from "@/components/containers/CreateAccountContainer"

export default function CreateAccountPage() {
  return <CreateAccountContainer />
}
