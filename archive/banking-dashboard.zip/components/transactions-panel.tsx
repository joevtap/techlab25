"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowDownLeft, ArrowUpRight, CreditCard, DollarSign } from "lucide-react"
import { cn } from "@/lib/utils"

// Mock data for transactions - in a real app, this would come from your backend
const mockTransactions = [
  {
    id: "1",
    type: "deposit",
    description: "Pagamento de Salário",
    amount: 3500.0,
    date: "2025-05-15T08:30:00",
    fromAccount: "Empresa Ltda.",
    toAccount: "1",
  },
  {
    id: "2",
    type: "withdrawal",
    description: "Pagamento de Aluguel",
    amount: 1200.0,
    date: "2025-05-10T14:45:00",
    fromAccount: "1",
    toAccount: "Imobiliária",
  },
  {
    id: "3",
    type: "payment",
    description: "Supermercado",
    amount: 87.35,
    date: "2025-05-08T18:20:00",
    fromAccount: "1",
    toAccount: "Mercado Central",
  },
  {
    id: "4",
    type: "deposit",
    description: "Reembolso",
    amount: 29.99,
    date: "2025-05-05T11:15:00",
    fromAccount: "Loja Online",
    toAccount: "1",
  },
  {
    id: "5",
    type: "payment",
    description: "Conta de Luz",
    amount: 145.5,
    date: "2025-05-03T09:30:00",
    fromAccount: "1",
    toAccount: "Companhia Elétrica",
  },
  {
    id: "6",
    type: "withdrawal",
    description: "Saque no Caixa",
    amount: 100.0,
    date: "2025-05-01T16:45:00",
    fromAccount: "1",
    toAccount: "Dinheiro",
  },
  {
    id: "7",
    type: "deposit",
    description: "Pagamento de Juros",
    amount: 12.37,
    date: "2025-04-30T00:00:00",
    fromAccount: "Banco",
    toAccount: "2",
  },
  {
    id: "8",
    type: "transfer",
    description: "Transferência para Poupança",
    amount: 500.0,
    date: "2025-04-28T10:15:00",
    fromAccount: "1",
    toAccount: "2",
  },
]

const periods = [
  { value: "7days", label: "Últimos 7 dias" },
  { value: "30days", label: "Últimos 30 dias" },
  { value: "90days", label: "Últimos 90 dias" },
  { value: "year", label: "Este ano" },
  { value: "all", label: "Todo período" },
]

export function TransactionsPanel() {
  const [selectedPeriod, setSelectedPeriod] = useState("30days")
  const [selectedAccountId, setSelectedAccountId] = useState("")
  const [transactions, setTransactions] = useState(mockTransactions)

  useEffect(() => {
    // Get selected account from localStorage
    const accountsJSON = localStorage.getItem("userAccounts")
    if (accountsJSON) {
      const accounts = JSON.parse(accountsJSON)
      if (accounts.length > 0 && !selectedAccountId) {
        setSelectedAccountId(accounts[0].id)
      }
    }

    // In a real app, you would fetch transactions from your backend
    // For demo purposes, we'll use the mock data
    setTransactions(mockTransactions)
  }, [selectedAccountId])

  // Filter transactions based on selected account and period
  const filteredTransactions = transactions.filter((transaction) => {
    const isForSelectedAccount =
      transaction.toAccount === selectedAccountId || transaction.fromAccount === selectedAccountId

    if (!isForSelectedAccount) return false

    const transactionDate = new Date(transaction.date)
    const now = new Date()

    switch (selectedPeriod) {
      case "7days":
        const sevenDaysAgo = new Date(now.setDate(now.getDate() - 7))
        return transactionDate >= sevenDaysAgo
      case "30days":
        const thirtyDaysAgo = new Date(now.setDate(now.getDate() - 30))
        return transactionDate >= thirtyDaysAgo
      case "90days":
        const ninetyDaysAgo = new Date(now.setDate(now.getDate() - 90))
        return transactionDate >= ninetyDaysAgo
      case "year":
        return transactionDate.getFullYear() === new Date().getFullYear()
      case "all":
      default:
        return true
    }
  })

  // Format currency in Brazilian Real
  const formatCurrency = (value: number) => {
    return value.toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
    })
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Histórico de Transações</CardTitle>
        <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Selecione o período" />
          </SelectTrigger>
          <SelectContent>
            {periods.map((period) => (
              <SelectItem key={period.value} value={period.value}>
                {period.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        {filteredTransactions.length === 0 ? (
          <div className="py-8 text-center text-muted-foreground">Nenhuma transação encontrada para este período</div>
        ) : (
          <div className="space-y-4">
            {filteredTransactions.map((transaction) => (
              <div key={transaction.id} className="flex items-center gap-4 py-2">
                <div
                  className={cn(
                    "flex h-10 w-10 items-center justify-center rounded-full",
                    transaction.type === "deposit"
                      ? "bg-green-100"
                      : transaction.type === "withdrawal"
                        ? "bg-red-100"
                        : transaction.type === "payment"
                          ? "bg-orange-100"
                          : "bg-blue-100",
                  )}
                >
                  {transaction.type === "deposit" ? (
                    <ArrowDownLeft className={cn("h-5 w-5", "text-green-600")} />
                  ) : transaction.type === "withdrawal" ? (
                    <ArrowUpRight className={cn("h-5 w-5", "text-red-600")} />
                  ) : transaction.type === "payment" ? (
                    <CreditCard className={cn("h-5 w-5", "text-orange-600")} />
                  ) : (
                    <DollarSign className={cn("h-5 w-5", "text-blue-600")} />
                  )}
                </div>
                <div className="flex-1 space-y-1">
                  <p className="font-medium">{transaction.description}</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(transaction.date).toLocaleDateString("pt-BR", {
                      year: "numeric",
                      month: "short",
                      day: "numeric",
                    })}
                  </p>
                </div>
                <div
                  className={cn(
                    "font-medium",
                    transaction.toAccount === selectedAccountId ? "text-green-600" : "text-red-600",
                  )}
                >
                  {transaction.toAccount === selectedAccountId ? "+" : "-"}
                  {formatCurrency(transaction.amount)}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
