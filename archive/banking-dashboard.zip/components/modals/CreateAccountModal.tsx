"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { formatCurrencyInput } from "@/lib/utils"

interface CreateAccountModalProps {
  isOpen: boolean
  onClose: () => void
}

export function CreateAccountModal({ isOpen, onClose }: CreateAccountModalProps) {
  const [accountType, setAccountType] = useState("")
  const [initialBalance, setInitialBalance] = useState("")
  const [formattedBalance, setFormattedBalance] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleBalanceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value, formattedValue } = formatCurrencyInput(e.target.value)
    setInitialBalance(value)
    setFormattedBalance(formattedValue)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!accountType || !initialBalance) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos obrigatórios",
        variant: "destructive",
      })
      return
    }

    const balance = Number.parseFloat(initialBalance)
    if (isNaN(balance) || balance < 0) {
      toast({
        title: "Erro",
        description: "Por favor, insira um saldo inicial válido",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      const existingAccountsJSON = localStorage.getItem("userAccounts")
      const existingAccounts = existingAccountsJSON ? JSON.parse(existingAccountsJSON) : []

      const accountTypeMap = {
        CHECKING: "Conta Corrente",
        SAVINGS: "Poupança",
        INVESTMENT: "Investimento",
      }

      const newAccount = {
        id: (existingAccounts.length + 1).toString(),
        type: accountTypeMap[accountType as keyof typeof accountTypeMap] || accountType,
        number: Math.floor(10000000 + Math.random() * 90000000).toString(),
        balance: balance,
        currency: "BRL",
      }

      const updatedAccounts = [...existingAccounts, newAccount]
      localStorage.setItem("userAccounts", JSON.stringify(updatedAccounts))
      localStorage.setItem("hasAccounts", "true")

      setIsLoading(false)
      toast({
        title: "Sucesso",
        description: "Conta criada com sucesso",
      })

      resetForm()
      onClose()

      // Force a page refresh to update the accounts list
      window.location.reload()
    }, 1000)
  }

  const resetForm = () => {
    setAccountType("")
    setInitialBalance("")
    setFormattedBalance("")
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Criar Nova Conta</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="accountType">Tipo de Conta</Label>
              <Select value={accountType} onValueChange={setAccountType}>
                <SelectTrigger id="accountType">
                  <SelectValue placeholder="Selecione o tipo de conta" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="CHECKING">Conta Corrente</SelectItem>
                  <SelectItem value="SAVINGS">Poupança</SelectItem>
                  <SelectItem value="INVESTMENT">Investimento</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="initialBalance">Saldo Inicial</Label>
              <Input
                id="initialBalance"
                value={formattedBalance}
                onChange={handleBalanceChange}
                placeholder="R$ 0,00"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Criando..." : "Criar Conta"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
