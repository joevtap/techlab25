"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { formatCurrencyInput, formatCurrency } from "@/lib/utils"

interface Account {
  id: string
  type: string
  number: string
  balance: number
  currency: string
}

interface WithdrawModalProps {
  isOpen: boolean
  onClose: () => void
  accounts: Account[]
  selectedAccountId: string
}

export function WithdrawModal({ isOpen, onClose, accounts, selectedAccountId }: WithdrawModalProps) {
  const [accountId, setAccountId] = useState(selectedAccountId)
  const [amount, setAmount] = useState("")
  const [formattedAmount, setFormattedAmount] = useState("")
  const [description, setDescription] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (selectedAccountId && isOpen) {
      setAccountId(selectedAccountId)
    }
  }, [selectedAccountId, isOpen])

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value, formattedValue } = formatCurrencyInput(e.target.value)
    setAmount(value)
    setFormattedAmount(formattedValue)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!accountId || !amount) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos obrigatórios",
        variant: "destructive",
      })
      return
    }

    const withdrawAmount = Number.parseFloat(amount)
    if (isNaN(withdrawAmount) || withdrawAmount <= 0) {
      toast({
        title: "Erro",
        description: "Por favor, insira um valor válido",
        variant: "destructive",
      })
      return
    }

    const account = accounts.find((account) => account.id === accountId)
    if (account && account.balance < withdrawAmount) {
      toast({
        title: "Erro",
        description: "Saldo insuficiente para este saque",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: "Sucesso",
        description: `Saque de ${formatCurrency(withdrawAmount)} realizado com sucesso`,
      })
      resetForm()
      onClose()
    }, 1000)
  }

  const resetForm = () => {
    setAccountId(selectedAccountId)
    setAmount("")
    setFormattedAmount("")
    setDescription("")
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Sacar Fundos</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="account">Conta de Origem</Label>
              <Select value={accountId} onValueChange={setAccountId}>
                <SelectTrigger id="account">
                  <SelectValue placeholder="Selecione a conta" />
                </SelectTrigger>
                <SelectContent>
                  {accounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.type} ({account.number})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="amount">Valor</Label>
              <Input id="amount" value={formattedAmount} onChange={handleAmountChange} placeholder="R$ 0,00" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Descrição (Opcional)</Label>
              <Input
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Descrição do saque"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Processando..." : "Sacar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
