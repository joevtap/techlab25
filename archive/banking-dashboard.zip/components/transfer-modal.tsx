"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"

interface Account {
  id: string
  type: string
  number: string
  balance: number
  currency: string
}

interface TransferModalProps {
  isOpen: boolean
  onClose: () => void
  accounts: Account[]
  selectedAccountId: string
}

export function TransferModal({ isOpen, onClose, accounts, selectedAccountId }: TransferModalProps) {
  const [fromAccountId, setFromAccountId] = useState(selectedAccountId)
  const [toAccountId, setToAccountId] = useState("")
  const [amount, setAmount] = useState("")
  const [formattedAmount, setFormattedAmount] = useState("")
  const [description, setDescription] = useState("")
  const [customAccountNumber, setCustomAccountNumber] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (selectedAccountId && isOpen) {
      setFromAccountId(selectedAccountId)
    }
  }, [selectedAccountId, isOpen])

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Remove non-numeric characters
    const value = e.target.value.replace(/\D/g, "")

    // Convert to number (in cents)
    const numericValue = Number.parseInt(value, 10) || 0

    // Store the actual value (in reais)
    setAmount((numericValue / 100).toString())

    // Format for display
    const formattedValue = (numericValue / 100).toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
    })

    setFormattedAmount(formattedValue)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!fromAccountId || !toAccountId || (toAccountId === "custom" && !customAccountNumber)) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos obrigatórios",
        variant: "destructive",
      })
      return
    }

    if (fromAccountId === toAccountId && toAccountId !== "custom") {
      toast({
        title: "Erro",
        description: "Não é possível transferir para a mesma conta",
        variant: "destructive",
      })
      return
    }

    const transferAmount = Number.parseFloat(amount)
    if (isNaN(transferAmount) || transferAmount <= 0) {
      toast({
        title: "Erro",
        description: "Por favor, insira um valor válido",
        variant: "destructive",
      })
      return
    }

    const fromAccount = accounts.find((account) => account.id === fromAccountId)
    if (fromAccount && fromAccount.balance < transferAmount) {
      toast({
        title: "Erro",
        description: "Saldo insuficiente para esta transferência",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: "Sucesso",
        description: `Transferência de ${(transferAmount).toLocaleString("pt-BR", {
          style: "currency",
          currency: "BRL",
        })} realizada com sucesso`,
      })
      resetForm()
      onClose()
    }, 1000)
  }

  const resetForm = () => {
    setFromAccountId(selectedAccountId)
    setToAccountId("")
    setAmount("")
    setFormattedAmount("")
    setDescription("")
    setCustomAccountNumber("")
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Transferir Dinheiro</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="fromAccount">Conta de Origem</Label>
              <Select value={fromAccountId} onValueChange={setFromAccountId}>
                <SelectTrigger id="fromAccount">
                  <SelectValue placeholder="Selecione a conta" />
                </SelectTrigger>
                <SelectContent>
                  {accounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.type} ({account.number})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="toAccount">Conta de Destino</Label>
              <div className="grid grid-cols-1 gap-2">
                <div className="flex items-center space-x-2">
                  <Select value={toAccountId} onValueChange={setToAccountId}>
                    <SelectTrigger id="toAccount" className="flex-1">
                      <SelectValue placeholder="Selecione a conta" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="custom">Digitar número da conta</SelectItem>
                      {accounts.map((account) => (
                        <SelectItem key={account.id} value={account.id} disabled={account.id === fromAccountId}>
                          {account.type} ({account.number})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {toAccountId === "custom" && (
                  <Input
                    id="customAccountNumber"
                    placeholder="Digite o número da conta"
                    value={customAccountNumber}
                    onChange={(e) => setCustomAccountNumber(e.target.value)}
                  />
                )}
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="amount">Valor</Label>
              <Input id="amount" value={formattedAmount} onChange={handleAmountChange} placeholder="R$ 0,00" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Descrição (Opcional)</Label>
              <Input
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Descrição da transferência"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Processando..." : "Transferir"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
