"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"

interface AuthFormProps {
  mode: "signin" | "signup"
  onSignIn: (email: string, password: string) => void
  onSignUp: (name: string, email: string, password: string, confirmPassword: string) => void
  isLoading: boolean
}

export function AuthForm({ mode, onSignIn, onSignUp, isLoading }: AuthFormProps) {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (mode === "signin") {
      if (!email || !password) {
        toast({
          title: "Erro",
          description: "Por favor, preencha todos os campos",
          variant: "destructive",
        })
        return
      }
      onSignIn(email, password)
    } else {
      if (!name || !email || !password || !confirmPassword) {
        toast({
          title: "Erro",
          description: "Por favor, preencha todos os campos",
          variant: "destructive",
        })
        return
      }
      onSignUp(name, email, password, confirmPassword)
    }
  }

  const isSignIn = mode === "signin"

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl font-bold">{isSignIn ? "Entrar" : "Criar uma conta"}</CardTitle>
        <CardDescription>
          {isSignIn
            ? "Digite seu email e senha para acessar sua conta"
            : "Digite suas informações para criar uma conta"}
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          {!isSignIn && (
            <div className="space-y-2">
              <Label htmlFor="name">Nome Completo</Label>
              <Input
                id="name"
                placeholder="João Silva"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
          )}
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="nome@exemplo.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            {isSignIn && (
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Senha</Label>
                <Link href="#" className="text-sm text-primary hover:underline">
                  Esqueceu a senha?
                </Link>
              </div>
            )}
            {!isSignIn && <Label htmlFor="password">Senha</Label>}
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          {!isSignIn && (
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirmar Senha</Label>
              <Input
                id="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>
          )}
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? (isSignIn ? "Entrando..." : "Criando conta...") : isSignIn ? "Entrar" : "Cadastrar"}
          </Button>
          <div className="text-center text-sm">
            {isSignIn ? "Não tem uma conta? " : "Já tem uma conta? "}
            <Link href={isSignIn ? "/sign-up" : "/sign-in"} className="text-primary hover:underline">
              {isSignIn ? "Cadastre-se" : "Entrar"}
            </Link>
          </div>
        </CardFooter>
      </form>
    </Card>
  )
}
