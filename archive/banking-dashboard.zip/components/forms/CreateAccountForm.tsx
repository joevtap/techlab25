"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { formatCurrencyInput } from "@/lib/utils"

interface CreateAccountFormProps {
  onSubmit: (accountType: string, initialBalance: number) => void
  isLoading: boolean
}

export function CreateAccountForm({ onSubmit, isLoading }: CreateAccountFormProps) {
  const [accountType, setAccountType] = useState("")
  const [initialBalance, setInitialBalance] = useState("")
  const [formattedBalance, setFormattedBalance] = useState("")

  const handleBalanceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value, formattedValue } = formatCurrencyInput(e.target.value)
    setInitialBalance(value)
    setFormattedBalance(formattedValue)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!accountType || !initialBalance) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos",
        variant: "destructive",
      })
      return
    }

    const balance = Number.parseFloat(initialBalance)
    if (isNaN(balance) || balance < 0) {
      toast({
        title: "Erro",
        description: "Por favor, insira um saldo inicial válido",
        variant: "destructive",
      })
      return
    }

    onSubmit(accountType, balance)
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl font-bold">Crie Sua Primeira Conta</CardTitle>
        <CardDescription>Configure uma conta bancária para começar</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="accountType">Tipo de Conta</Label>
            <Select value={accountType} onValueChange={setAccountType} required>
              <SelectTrigger id="accountType">
                <SelectValue placeholder="Selecione o tipo de conta" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="CHECKING">Conta Corrente</SelectItem>
                <SelectItem value="SAVINGS">Poupança</SelectItem>
                <SelectItem value="INVESTMENT">Investimento</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="initialBalance">Saldo Inicial</Label>
            <Input
              id="initialBalance"
              value={formattedBalance}
              onChange={handleBalanceChange}
              placeholder="R$ 0,00"
              required
            />
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? "Criando conta..." : "Criar Conta"}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
