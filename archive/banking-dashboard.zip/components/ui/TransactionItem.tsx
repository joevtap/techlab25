import { ArrowDownLeft, ArrowUpRight, CreditCard, DollarSign } from "lucide-react"
import { cn } from "@/lib/utils"
import { formatCurrency } from "@/lib/utils"

interface Transaction {
  id: string
  type: string
  description: string
  amount: number
  date: string
  fromAccount: string
  toAccount: string
}

interface TransactionItemProps {
  transaction: Transaction
  selectedAccountId: string
}

export function TransactionItem({ transaction, selectedAccountId }: TransactionItemProps) {
  const getTransactionIcon = () => {
    switch (transaction.type) {
      case "deposit":
        return <ArrowDownLeft className="h-5 w-5 text-green-600" />
      case "withdrawal":
        return <ArrowUpRight className="h-5 w-5 text-red-600" />
      case "payment":
        return <CreditCard className="h-5 w-5 text-orange-600" />
      default:
        return <DollarSign className="h-5 w-5 text-blue-600" />
    }
  }

  const getTransactionColor = () => {
    switch (transaction.type) {
      case "deposit":
        return "bg-green-100"
      case "withdrawal":
        return "bg-red-100"
      case "payment":
        return "bg-orange-100"
      default:
        return "bg-blue-100"
    }
  }

  const isIncoming = transaction.toAccount === selectedAccountId

  return (
    <div className="flex items-center gap-4 py-2">
      <div className={cn("flex h-10 w-10 items-center justify-center rounded-full", getTransactionColor())}>
        {getTransactionIcon()}
      </div>
      <div className="flex-1 space-y-1">
        <p className="font-medium">{transaction.description}</p>
        <p className="text-sm text-muted-foreground">
          {new Date(transaction.date).toLocaleDateString("pt-BR", {
            year: "numeric",
            month: "short",
            day: "numeric",
          })}
        </p>
      </div>
      <div className={cn("font-medium", isIncoming ? "text-green-600" : "text-red-600")}>
        {isIncoming ? "+" : "-"}
        {formatCurrency(transaction.amount)}
      </div>
    </div>
  )
}
