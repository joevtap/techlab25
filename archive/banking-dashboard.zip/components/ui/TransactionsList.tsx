import { TransactionItem } from "@/components/ui/TransactionItem"

interface Transaction {
  id: string
  type: string
  description: string
  amount: number
  date: string
  fromAccount: string
  toAccount: string
}

interface TransactionsListProps {
  transactions: Transaction[]
  selectedAccountId: string
}

export function TransactionsList({ transactions, selectedAccountId }: TransactionsListProps) {
  if (transactions.length === 0) {
    return <div className="py-8 text-center text-muted-foreground">Nenhuma transação encontrada para este período</div>
  }

  return (
    <div className="space-y-4">
      {transactions.map((transaction) => (
        <TransactionItem key={transaction.id} transaction={transaction} selectedAccountId={selectedAccountId} />
      ))}
    </div>
  )
}
