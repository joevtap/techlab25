"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { AuthForm } from "@/components/forms/AuthForm"
import { toast } from "@/components/ui/use-toast"

interface AuthContainerProps {
  mode: "signin" | "signup"
}

export function AuthContainer({ mode }: AuthContainerProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)

  const handleSignIn = async (email: string, password: string) => {
    setIsLoading(true)

    // Simulate authentication
    setTimeout(() => {
      localStorage.setItem("isAuthenticated", "true")
      localStorage.setItem("userEmail", email)

      setIsLoading(false)
      toast({
        title: "Sucesso",
        description: "Login realizado com sucesso",
      })

      router.push("/dashboard")
    }, 1000)
  }

  const handleSignUp = async (name: string, email: string, password: string, confirmPassword: string) => {
    if (password !== confirmPassword) {
      toast({
        title: "Erro",
        description: "As senhas não coincidem",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    // Simulate user registration
    setTimeout(() => {
      localStorage.setItem("isAuthenticated", "true")
      localStorage.setItem("userEmail", email)
      localStorage.setItem("userName", name)
      localStorage.setItem("hasAccounts", "false")

      setIsLoading(false)
      toast({
        title: "Sucesso",
        description: "Sua conta foi criada com sucesso",
      })

      router.push("/create-account")
    }, 1000)
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <AuthForm mode={mode} onSignIn={handleSignIn} onSignUp={handleSignUp} isLoading={isLoading} />
    </div>
  )
}
