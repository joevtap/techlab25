"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { CreateAccountForm } from "@/components/forms/CreateAccountForm"
import { toast } from "@/components/ui/use-toast"

export function CreateAccountContainer() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    // Check if user is authenticated
    const isAuthenticated = localStorage.getItem("isAuthenticated") === "true"
    if (!isAuthenticated) {
      router.push("/sign-in")
    }
  }, [router])

  const handleCreateAccount = async (accountType: string, initialBalance: number) => {
    setIsLoading(true)

    // Simulate account creation
    setTimeout(() => {
      const accountTypeMap = {
        CHECKING: "Conta Corrente",
        SAVINGS: "Poupança",
        INVESTMENT: "Investimento",
      }

      const mockAccounts = [
        {
          id: "1",
          type: accountTypeMap[accountType as keyof typeof accountTypeMap] || accountType,
          number: Math.floor(10000000 + Math.random() * 90000000).toString(),
          balance: initialBalance,
          currency: "BRL",
        },
      ]

      localStorage.setItem("hasAccounts", "true")
      localStorage.setItem("userAccounts", JSON.stringify(mockAccounts))

      setIsLoading(false)
      toast({
        title: "Sucesso",
        description: "Sua conta foi criada com sucesso",
      })

      router.push("/dashboard")
    }, 1000)
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <CreateAccountForm onSubmit={handleCreateAccount} isLoading={isLoading} />
    </div>
  )
}
