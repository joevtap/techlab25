"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Header } from "@/components/ui/Header"
import { AccountsContainer } from "@/components/containers/AccountsContainer"
import { TransactionsContainer } from "@/components/containers/TransactionsContainer"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import { CreateAccountModal } from "@/components/modals/CreateAccountModal"
import { EmptyState } from "@/components/ui/EmptyState"

export function DashboardContainer() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [hasAccounts, setHasAccounts] = useState(true)
  const [isCreateAccountModalOpen, setIsCreateAccountModalOpen] = useState(false)

  useEffect(() => {
    // Check if user is authenticated
    const authStatus = localStorage.getItem("isAuthenticated") === "true"
    setIsAuthenticated(authStatus)

    if (!authStatus) {
      router.push("/sign-in")
      return
    }

    // Check if user has accounts
    const accountStatus = localStorage.getItem("hasAccounts") === "true"
    setHasAccounts(accountStatus)
  }, [router])

  if (!isAuthenticated) {
    return null // Will redirect in useEffect
  }

  return (
    <main className="min-h-screen bg-gray-50">
      <Header />
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Minhas Contas</h1>
          <Button onClick={() => setIsCreateAccountModalOpen(true)} className="flex items-center gap-2">
            <PlusCircle className="h-4 w-4" />
            Nova Conta
          </Button>
        </div>

        {hasAccounts ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1">
              <AccountsContainer />
            </div>
            <div className="lg:col-span-2">
              <TransactionsContainer />
            </div>
          </div>
        ) : (
          <EmptyState
            title="Você ainda não possui contas"
            description="Crie sua primeira conta para começar"
            actionLabel="Criar Conta"
            onAction={() => setIsCreateAccountModalOpen(true)}
            icon={<PlusCircle className="h-4 w-4" />}
          />
        )}
      </div>

      <CreateAccountModal isOpen={isCreateAccountModalOpen} onClose={() => setIsCreateAccountModalOpen(false)} />
    </main>
  )
}
