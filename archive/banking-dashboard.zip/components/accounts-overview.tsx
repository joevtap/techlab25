"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { PlusCircle, MinusCircle, ArrowRightLeft } from "lucide-react"
import { cn } from "@/lib/utils"
import { TransferModal } from "@/components/transfer-modal"
import { DepositModal } from "@/components/deposit-modal"
import { WithdrawModal } from "@/components/withdraw-modal"

interface Account {
  id: string
  type: string
  number: string
  balance: number
  currency: string
}

export function AccountsOverview() {
  const [accounts, setAccounts] = useState<Account[]>([])
  const [selectedAccountId, setSelectedAccountId] = useState("")
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false)
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false)
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false)

  useEffect(() => {
    // Load accounts from localStorage
    const accountsJSON = localStorage.getItem("userAccounts")
    if (accountsJSON) {
      const loadedAccounts = JSON.parse(accountsJSON)
      setAccounts(loadedAccounts)

      // Set the first account as selected by default
      if (loadedAccounts.length > 0 && !selectedAccountId) {
        setSelectedAccountId(loadedAccounts[0].id)
      }
    }
  }, [selectedAccountId])

  const selectedAccount = accounts.find((account) => account.id === selectedAccountId)

  // Format currency in Brazilian Real
  const formatCurrency = (value: number) => {
    return value.toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
    })
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-2">
        <Button
          variant="outline"
          size="sm"
          className="flex items-center gap-1 w-full"
          onClick={() => setIsTransferModalOpen(true)}
          disabled={accounts.length < 1}
        >
          <ArrowRightLeft className="h-4 w-4" />
          <span>Transferir</span>
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="flex items-center gap-1 w-full"
          onClick={() => setIsDepositModalOpen(true)}
          disabled={accounts.length < 1}
        >
          <PlusCircle className="h-4 w-4" />
          <span>Depositar</span>
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="flex items-center gap-1 w-full"
          onClick={() => setIsWithdrawModalOpen(true)}
          disabled={accounts.length < 1}
        >
          <MinusCircle className="h-4 w-4" />
          <span>Sacar</span>
        </Button>
      </div>
      {accounts.length === 0 ? (
        <Card>
          <CardContent className="py-6">
            <p className="text-center text-muted-foreground">Nenhuma conta encontrada</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {accounts.map((account) => (
            <Card
              key={account.id}
              className={cn(
                "cursor-pointer transition-colors hover:bg-gray-50",
                selectedAccountId === account.id && "border-primary bg-primary/5",
              )}
              onClick={() => setSelectedAccountId(account.id)}
            >
              <CardHeader className="py-4 px-5">
                <CardTitle className="text-base font-medium">{account.type}</CardTitle>
              </CardHeader>
              <CardContent className="py-2 px-5">
                <div className="flex justify-between items-center">
                  <div className="text-sm text-muted-foreground">{account.number}</div>
                  <div className="text-lg font-semibold">{formatCurrency(account.balance)}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      {accounts.length > 0 && (
        <div className="pt-4">
          <Card>
            <CardHeader className="py-4 px-5">
              <CardTitle className="text-base font-medium">Saldo Total</CardTitle>
            </CardHeader>
            <CardContent className="py-2 px-5">
              <div className="text-2xl font-bold">
                {formatCurrency(accounts.reduce((sum, account) => sum + account.balance, 0))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Modals */}
      {accounts.length > 0 && (
        <>
          <TransferModal
            isOpen={isTransferModalOpen}
            onClose={() => setIsTransferModalOpen(false)}
            accounts={accounts}
            selectedAccountId={selectedAccountId}
          />

          <DepositModal
            isOpen={isDepositModalOpen}
            onClose={() => setIsDepositModalOpen(false)}
            accounts={accounts}
            selectedAccountId={selectedAccountId}
          />

          <WithdrawModal
            isOpen={isWithdrawModalOpen}
            onClose={() => setIsWithdrawModalOpen(false)}
            accounts={accounts}
            selectedAccountId={selectedAccountId}
          />
        </>
      )}
    </div>
  )
}
