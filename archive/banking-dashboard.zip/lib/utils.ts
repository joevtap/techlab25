import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Format currency in Brazilian Real
export function formatCurrency(value: number): string {
  return value.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  })
}

// Format currency input with mask
export function formatCurrencyInput(inputValue: string): { value: string; formattedValue: string } {
  // Remove non-numeric characters
  const value = inputValue.replace(/\D/g, "")

  // Convert to number (in cents)
  const numericValue = Number.parseInt(value, 10) || 0

  // Store the actual value (in reais)
  const actualValue = (numericValue / 100).toString()

  // Format for display
  const formattedValue = (numericValue / 100).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  })

  return {
    value: actualValue,
    formattedValue,
  }
}
